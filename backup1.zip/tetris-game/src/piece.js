class Piece {
    constructor(type) {
        const tetrominoes = {
            I: { shape: [[1, 1, 1, 1]], score: 40 },
            O: { shape: [[1, 1], [1, 1]], score: 30 },
            T: { shape: [[0, 1, 0], [1, 1, 1]], score: 50 },
            S: { shape: [[0, 1, 1], [1, 1, 0]], score: 60 },
            Z: { shape: [[1, 1, 0], [0, 1, 1]], score: 60 },
            J: { shape: [[1, 0, 0], [1, 1, 1]], score: 70 },
            L: { shape: [[0, 0, 1], [1, 1, 1]], score: 70 }
        };

        const keys = Object.keys(tetrominoes);
        const randomKey = type || keys[Math.floor(Math.random() * keys.length)];
        this.shape = tetrominoes[randomKey].shape;
        this.scoreValue = tetrominoes[randomKey].score;
        this.position = { x: 3, y: 0 }; // Start position
    }

    draw(context) {
        this.shape.forEach((row, y) => {
            row.forEach((value, x) => {
                if (value) {
                    context.fillStyle = 'blue';
                    context.fillRect((this.position.x + x) * 30, (this.position.y + y) * 30, 30, 30);
                    context.strokeRect((this.position.x + x) * 30, (this.position.y + y) * 30, 30, 30);
                }
            });
        });
    }

    moveDown() {
        this.position.y++;
    }

    moveLeft() {
        this.position.x--;
    }

    moveRight() {
        this.position.x++;
    }

    canMoveDown(board) {
        const newPosition = { x: this.position.x, y: this.position.y + 1 };
        const coordinates = this.getCoordinates(newPosition);

        for (let coord of coordinates) {
            if (coord.y >= board.rows || board.grid[coord.y][coord.x] !== 0) {
                return false;
            }
        }

        return true;
    }

   canMoveLeft(board) {
        const newPosition = { x: this.position.x - 1, y: this.position.y };
        const coordinates = this.getCoordinates(newPosition);

        for (let coord of coordinates) {
            if (coord.x < 0 || board.grid[coord.y][coord.x] !== 0) {
                return false;
            }
        }

        return true;
    }

    canMoveRight(board) {
        const newPosition = { x: this.position.x + 1, y: this.position.y };
        const coordinates = this.getCoordinates(newPosition);

        for (let coord of coordinates) {
            if (coord.x >= board.columns || board.grid[coord.y][coord.x] !== 0) {
                return false;
            }
        }

        return true;
    }

    undoRotate() {
        // This is a placeholder.  Ideally, you'd store the previous rotation.
        this.rotate();
        this.rotate();
        this.rotate();
    }

    rotate() {
        this.shape = this.shape[0].map((val, index) =>
            this.shape.map(row => row[index]).reverse()
        );
    }

    move(direction) {
        this.position.x += direction.x;
        this.position.y += direction.y;
    }

    getCoordinates(position = this.position) {
        const coordinates = [];
        this.shape.forEach((row, y) => {
            row.forEach((value, x) => {
                if (value) {
                    coordinates.push({ x: position.x + x, y: position.y + y });
                }
            });
        });
        return coordinates;
    }

    getScoreValue() {
        return this.scoreValue;
    }
}