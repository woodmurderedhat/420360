// This file manages the overall game state. It handles the spawning of new pieces, collision detection, and scoring. It also manages the game over state and restarts the game.

const canvas = document.getElementById('tetris');
const context = canvas.getContext('2d');

const board = new Board();
let piece;
let score = 0;
let gameOver = false;
let lastTime = 0;
let dropInterval = 500; // Default speed (milliseconds)

const playerNameInput = document.getElementById('player-name');
const scoreElement = document.getElementById('score');
const gameInfoElement = document.getElementById('game-info');
const startGameButton = document.getElementById('start-game-button');

// Function to set the game speed
function setGameSpeed(speed) {
    dropInterval = speed;
}

// Update the score display
function updateScore() {
    scoreElement.textContent = `Score: ${score}`;
}

// Update game info
function updateGameInfo(info) {
    gameInfoElement.textContent = `Game Info: ${info}`;
}

startGameButton.addEventListener('click', () => {
    const playerName = playerNameInput.value.trim();
    if (!playerName) {
        alert('Please enter your name to start the game.');
        return;
    }
    leaderboard.displayScores(); // Ensure leaderboard is updated before starting
    startGame();
});

function startGame() {
    score = 0;
    gameOver = false;
    board.reset();
    spawnPiece();
    updateScore();
    updateGameInfo('Game Started');
    lastTime = 0; // Reset the lastTime for the game loop
    requestAnimationFrame(update); // Start the game loop
}

function calculateScore(linesCleared) {
    const pieceScore = piece.getScoreValue(); // Get the unique score value of the current piece
    return linesCleared * pieceScore;
}

function spawnPiece() {
    piece = new Piece();
    piece.position = {x: 3, y: 0}; // Reset position when spawning
    if (board.collides(piece)) {
        gameOver = true;
        updateGameInfo('Game Over');
        const playerName = playerNameInput.value.trim() || 'Player';
        leaderboard.addScore(playerName, score); // Add score to leaderboard
        leaderboard.displayScores(); // Update leaderboard display
        alert(`Game Over! ${playerName}, your score: ${score}`);
    }
}

let coyoteTime = 500; // 500ms coyote time
let coyoteTimerActive = false;

function update(time = 0) {
    if (gameOver) return;

    const deltaTime = time - lastTime;
    if (deltaTime > dropInterval) {
        context.clearRect(0, 0, canvas.width, canvas.height);
        board.draw(context);
        piece.draw(context);

        if (piece.canMoveDown(board)) {
            piece.moveDown();
            coyoteTimerActive = false; // Reset coyote timer when the piece moves down
        } else {
            if (!coyoteTimerActive) {
                coyoteTimerActive = true;
                setTimeout(() => {
                    if (!piece.canMoveDown(board)) {
                        board.mergePiece(piece);
                        const linesCleared = board.clearLines();
                        if (linesCleared > 0) {
                            score += calculateScore(linesCleared); // Update score based on lines cleared
                            updateScore();
                        }
                        spawnPiece();
                    }
                }, coyoteTime);
            }
        }

        lastTime = time;
    }

    requestAnimationFrame(update);
}

// Example: Change speed dynamically
setGameSpeed(1000); // Slower speed (1 second per drop)

document.addEventListener('keydown', (event) => {
    if (gameOver) return;

    switch (event.key) {
        case 'ArrowLeft':
            if (piece.canMoveLeft(board)) {
                piece.moveLeft();
            }
            break;
        case 'ArrowRight':
            if (piece.canMoveRight(board)) {
                piece.moveRight();
            }
            break;
        case 'ArrowDown':
            if (piece.canMoveDown(board)) {
                piece.moveDown();
            }
            break;
        case 'ArrowUp':
            piece.rotate();
            if (board.collides(piece)) {
                piece.undoRotate();
            }
            break;
    }

    updateScore();
});